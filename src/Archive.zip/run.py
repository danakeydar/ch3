from  model import *
from conf import *
import dataset as Dataset
from torchmetrics import SpearmanCorrCoef

load_model_ID = 0  
train, validation, test, validation_ch3_blind, test_ch3_blind, validation_e_blind, test_e_blind = Dataset.read_data_sets(
    filename_sequence=Conf.filename_sequence,
    filename_expression=Conf.filename_expression,
    filename_labels=Conf.filename_labels,
    filename_dist=Conf.filename_dist,
    train_portion_subjects=Conf.train_portion_probes,
    train_portion_probes=Conf.train_portion_probes, validation_portion_subjects=Conf.validation_portion_subjects,
    validation_portion_probes=Conf.validation_portion_probes, directory='', load_model_ID=load_model_ID)

multi_model = MultiModel()
multi_model = multi_model.float()

lr = 0.001
optimizer = optim.Adam(multi_model.parameters(), lr=lr)
loss_fn = nn.L1Loss()

for epoch in range(Conf.epochs):
  val_losses=[]; train_losses=[]; train_corrs =[]; val_corrs=[]
  for ii in range(train.num_examples // Conf.batch_size):
    # multi_model.train()
    train_seq_batch, train_exp_batch, train_dist_batch, train_labels_batch = get_next_batch(train, Conf.batch_size)
    optimizer.zero_grad()
    train_predictions = multi_model(train_seq_batch.float(), train_dist_batch.float(), train_exp_batch.float())
    
    train_loss = loss_fn(train_predictions, train_labels_batch)
    train_losses.append(train_loss.detach().numpy())
    train_spearman = SpearmanCorrCoef()
    train_corr = train_spearman(train_predictions.squeeze(), train_labels_batch.squeeze())
    train_corrs.append(train_corr)
    
    train_loss.backward()
    optimizer.step()
    
    # multi_model.eval()
    with torch.no_grad():
      val_seq_batch, val_exp_batch, val_dist_batch, val_labels_batch = get_next_batch(validation, Conf.batch_size*2)
      val_predictions = multi_model(val_seq_batch, val_dist_batch, val_exp_batch)
      val_loss = loss_fn(val_predictions, val_labels_batch)
      val_losses.append(val_loss)
      val_spearman = SpearmanCorrCoef()
      val_corr = val_spearman(val_predictions.squeeze(), val_labels_batch.squeeze())
      val_corrs.append(val_corr)
  print(f"-------------------------------Epoch {epoch +1}/{Conf.epochs}-------------------------------")
  print("Train      | Loss: {:.3f} Corr: {:.3f}".format(np.mean(train_losses), np.mean(train_corrs)))
  print("Validation | Loss: {:.3f} Corr: {:.3f}".format(np.mean(val_losses), np.mean(val_corrs)))
  print("-----------------------------------------------------------------------")

print("Finish training")

plt.plot(val_losses)
plt.plot(train_losses)
plt.show()